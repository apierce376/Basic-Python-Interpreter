print 4
