print "True + True = "; print True + True ; print
print "True + 1 = "; print True + 1 ; print
print "True + 2.0 = "; print True + 2.0 ; print

print "True - True = "; print True - True ; print
print "1 - True = "; print 1 - True ; print
print "2.0 - True = "; print 2.0 - True ; print

print "True * True = "; print True * True ; print
print "True * 1 = "; print True * 1 ; print
print "True * 2.0 = "; print True * 2.0 ; print

print "True / True = "; print True / True ; print
print "True / 1 = "; print True / 1 ; print
print "True / 2.0 = "; print True / 2.0 ; print

print "True < True = "; print True < True ; print
print "True < 1 = "; print True < 1 ; print
print "True < 2.0 = "; print True < 2.0 ; print
print "True < '2.0' = "; print True < '2.0' ; print

print "True <= True = "; print True <= True ; print
print "True <= 1 = "; print True <= 1 ; print
print "True <= 2.0 = "; print True <= 2.0 ; print
print "True <= '2.0' = "; print True <= '2.0' ; print

print "True > True = "; print True > True ; print
print "True > 1 = "; print True > 1 ; print
print "True > 2.0 = "; print True > 2.0 ; print
print "True > '2.0' = "; print True > '2.0' ; print

print "True >= True = "; print True >= True ; print
print "True >= 1 = "; print True >= 1 ; print
print "True >= 2.0 = "; print True >= 2.0 ; print
print "True >= '2.0' = "; print True >= '2.0' ; print

print "True == True = "; print True == True ; print
print "True == 1 = "; print True == 1 ; print
print "True == 2.0 = "; print True == 2.0 ; print
print "True == '2.0' = "; print True == '2.0' ; print

print "True != True = "; print True != True ; print
print "True != 1 = "; print True != 1 ; print
print "True != 2.0 = "; print True != 2.0 ; print
print "True != '2.0' = "; print True != '2.0' ; print

